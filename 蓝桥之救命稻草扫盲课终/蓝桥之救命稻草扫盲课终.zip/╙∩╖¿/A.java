package �﷨;

public class A {

}
